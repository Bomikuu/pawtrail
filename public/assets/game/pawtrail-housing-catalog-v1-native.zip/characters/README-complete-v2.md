# PawTrail player catalog v2

Three complete appearance sheets contain the 27 requested action rows per appearance: eight movement/idles, nine social gestures, six animal-care actions and four decoration actions. Each action has four generated frames. Total: 81 strips, 324 frames at 32×48.

- Rescuer: short dark hair, medium-brown skin, sage shirt, rust shorts and tan backpack.
- Jacket rescuer: curly black hair, deep-brown skin, teal jacket, charcoal trousers and rust backpack.
- Braided rescuer: light warm-tan skin, chestnut braid, cream hat, ochre shirt, forest pants and sage backpack.

`complete-characters-manifest.json` indexes per-appearance manifests and actual native PNGs under `animations/`. Original source renders and exact built-in imagegen prompts/jobs are retained. Source alpha row bands were inspected/detected before extraction, so the manifests record actual source rectangles rather than assuming uniformly spaced rows.

A targeted imagegen edit repaired the jacket-care sheet's shorts/long-trouser mismatch. The bottom holding-item rows in dense social sheets had cropped feet; separately generated four-frame holding strips supplied native bottom shoe pixels only, retaining each original upper-body pose and identity. Original pre-repair sources remain available.

Native exports use binary transparency, nearest-neighbor sampling, palette cleanup and foot baseline y46. Every action has at least two distinct native frames; all frame dimensions/transparency/nonempty-cell checks were inspected. These counts do not certify smooth looping. Walking and idle rows repeat; social/care/decoration rows are one-shot transitions with final-pose hold available to a future engine.

Production readiness remains false. Wide-prop and wide-arm rows are fitted into the required 32-pixel width and consequently can have smaller heads than movement rows. Perfect cross-action proportions need pixel rigging/art refinement. There are no modular clothing layers or multiplayer/gameplay implementations; separate appearance spritesheets provide the requested appearance variants.
